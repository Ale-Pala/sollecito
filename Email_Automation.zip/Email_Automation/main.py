from pathlib import Path
import pandas as pd
import openpyxl
import win32com.client as win32

#Localizzare file base e creare cartella d'output (costanti)
EXCEL_FILE_PATH = Path.cwd() / "Data_Base_Excel.xlsx"
ATTACHMENT_DIR = Path.cwd() / "Allegati"

ATTACHMENT_DIR.mkdir(exist_ok=True)

#Caricamento dati nella cornice dati (dataframe)
data = pd.read_excel(EXCEL_FILE_PATH, sheet_name="data")
data.head()
print(data)

#Ottenimento valori univoci da colonna indicata
column_name = "Ragione_sociale"
unique_values = data[column_name].unique()
print(unique_values)

#Filtrare i dati per fornitore
for unique_value in unique_values:
    data_output= data.query(f"{column_name} == @unique_value")
    output_path = ATTACHMENT_DIR / f"{unique_value}.xlsx"
    data_output.to_excel(output_path, sheet_name=unique_value, index=False)

#Caricamento email fornitori
email_list = pd.read_excel(EXCEL_FILE_PATH, sheet_name="emails")
print(email_list)

#Iterazione email fornitori e invio email in Outlook
outlook = win32.Dispatch("outlook.application")
for index, row in email_list.iterrows():
    mail = outlook.CreateItem(0)
    mail.To = row["email"]
    mail.CC = row["CC"]
    mail.Subject = f"Sollecito portafoglio ordini aperti: {row['Ragione Sociale']}"

    #Corpo mail
    mail.HTMLBody = f"""
                    Buongiorno, <br><br>
                    Con la presente per chiedere cortese aggiornamento in merito al pacchetto ordini allegato.<br><br>
                    Attendiamo conferma delle date di consegna contrattuali e comunicazione tempestiva di eventuali ritardi o problematiche.<br><br>
                    Ringraziamo per la collaborazione e auguriamo buon lavoro.                   
                    """

    attachment_path = str(ATTACHMENT_DIR / f"{row['Ragione Sociale']}.xlsx")
    mail.Attachments.Add(Source=attachment_path)


    #Visibilità email
    mail.Display()





