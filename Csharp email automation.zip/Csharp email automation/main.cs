using System;
using System.IO;
using System.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace PythonToCSharpTranslation
{
    class Program
    {
        static void Main(string[] args)
        {
            string excelFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Data_Base_Excel.xlsx");
            string attachmentDirPath = Path.Combine(Directory.GetCurrentDirectory(), "Allegati");

            Directory.CreateDirectory(attachmentDirPath);

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workbook = excelApp.Workbooks.Open(excelFilePath);
            Excel.Worksheet dataSheet = workbook.Sheets["data"];

            Excel.Range usedRange = dataSheet.UsedRange;
            object[,] data = usedRange.Value;

            int numRows = data.GetLength(0);
            int numCols = data.GetLength(1);

            for (int rowIndex = 2; rowIndex <= numRows; rowIndex++)
            {
                string ragioneSociale = data[rowIndex, 1].ToString();
                Excel.Workbook newWorkbook = excelApp.Workbooks.Add();
                Excel.Worksheet newWorksheet = newWorkbook.Sheets[1];

                for (int colIndex = 1; colIndex <= numCols; colIndex++)
                {
                    newWorksheet.Cells[1, colIndex] = data[1, colIndex];
                    newWorksheet.Cells[2, colIndex] = data[rowIndex, colIndex];
                }

                string outputFilePath = Path.Combine(attachmentDirPath, $"{ragioneSociale}.xlsx");
                newWorkbook.SaveAs(outputFilePath);
                newWorkbook.Close();
            }

            workbook.Close();
            excelApp.Quit();

            Outlook.Application outlookApp = new Outlook.Application();
            Outlook.MailItem mail = outlookApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;

            Excel.Worksheet emailSheet = workbook.Sheets["emails"];
            Excel.Range emailRange = emailSheet.UsedRange;
            object[,] emailData = emailRange.Value;

            for (int rowIndex = 2; rowIndex <= emailData.GetLength(0); rowIndex++)
            {
                mail.To = emailData[rowIndex, 1].ToString();
                mail.CC = emailData[rowIndex, 2].ToString();
                mail.Subject = $"Sollecito portafoglio ordini aperti: {emailData[rowIndex, 3]}";

                string body = $"Buongiorno, <br><br> Con la presente per chiedere cortese aggiornamento...";
                mail.HTMLBody = body;

                string attachmentPath = Path.Combine(attachmentDirPath, $"{emailData[rowIndex, 3]}.xlsx");
                mail.Attachments.Add(attachmentPath);

                mail.Display();
            }

            Marshal.ReleaseComObject(excelApp);
            Marshal.ReleaseComObject(outlookApp);

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
